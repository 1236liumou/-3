"""
Stage 5: 字符识别模块
对分割出的单个字符图像进行识别

提供三种识别方案:
  1. 模板匹配: 简单直观，适合课程演示，无需训练
  2. SVM:      传统机器学习，需要少量训练数据
  3. CNN:      深度学习，准确率最高，需要较多训练数据

字符集:
  位置1: 省份简称 (31个汉字)
  位置2: 字母 (A-Z, 不含I/O)
  位置3-7: 字母+数字
"""

import cv2
import numpy as np
import os
import pickle
from .config import CHAR_RECOGNITION_CONFIG, TEMPLATE_DIR
from .utils import timer, imread_unicode


# 字符标签映射表 (索引 -> 字符)
def build_char_map(config=None):
    """构建标签索引到字符的映射字典"""
    cfg = config or CHAR_RECOGNITION_CONFIG
    char_map = {}
    idx = 0
    for p in cfg["provinces"]:
        char_map[idx] = p
        idx += 1
    for l in cfg["letters"]:
        char_map[idx] = l
        idx += 1
    for d in cfg["digits"]:
        char_map[idx] = d
        idx += 1
    return char_map


def build_char_to_label(config=None):
    """构建字符到标签索引的映射字典"""
    cfg = config or CHAR_RECOGNITION_CONFIG
    char_to_label = {}
    idx = 0
    for p in cfg["provinces"]:
        char_to_label[p] = idx
        idx += 1
    for l in cfg["letters"]:
        char_to_label[l] = idx
        idx += 1
    for d in cfg["digits"]:
        char_to_label[d] = idx
        idx += 1
    return char_to_label


# 总类别数: 31省 + 24字母 + 10数字 = 65
NUM_CLASSES = 65


class CharRecognizer:
    """字符识别器"""

    def __init__(self, config=None):
        self.config = config or CHAR_RECOGNITION_CONFIG
        self.method = self.config["method"]
        self.templates = {}
        self.svm_model = None
        self.cnn_model = None
        self._timings = {}
        self._load_models()

    def _load_models(self):
        """加载对应的模型"""
        if self.method == "template":
            self._load_templates()
        elif self.method == "svm":
            self._load_svm()
        elif self.method == "cnn":
            self._load_cnn()

    @timer
    def _load_templates(self):
        """
        加载字符模板
        模板目录结构: templates/
                      ├── provinces/  (省份汉字模板)
                      ├── letters/    (字母模板)
                      └── digits/     (数字模板)
        每个模板为 20x28 的二值化图像

        如果模板目录不存在，会使用内置的简单生成方法
        """
        template_dir = TEMPLATE_DIR
        categories = {
            "provinces": self.config["provinces"],
            "letters": self.config["letters"],
            "digits": self.config["digits"],
        }

        for category, chars in categories.items():
            self.templates[category] = {}
            cat_dir = template_dir / category

            for char in chars:
                template_path = cat_dir / f"{char}.png"
                if template_path.exists():
                    template = imread_unicode(str(template_path), cv2.IMREAD_GRAYSCALE)
                    if template is not None:
                        _, template = cv2.threshold(template, 127, 255, cv2.THRESH_BINARY)
                        self.templates[category][char] = template

        # 如果没有加载到任何模板，使用合成模板 (仅用于演示)
        if not self.templates.get("provinces"):
            self._generate_synthetic_templates()

    def _generate_synthetic_templates(self):
        """
        生成合成模板 (当没有真实模板时)
        使用 OpenCV 文字渲染生成简单模板
        注意: 合成模板仅用于功能演示，实际使用需要真实模板
        """
        font = cv2.FONT_HERSHEY_SIMPLEX
        size = self.config["cnn_input_size"]

        # 数字模板
        self.templates["digits"] = {}
        for d in self.config["digits"]:
            canvas = np.zeros((size[1], size[0]), dtype=np.uint8)
            cv2.putText(canvas, d, (5, 22), font, 0.7, 255, 2, cv2.LINE_AA)
            self.templates["digits"][d] = canvas

        # 字母模板
        self.templates["letters"] = {}
        for l in self.config["letters"]:
            canvas = np.zeros((size[1], size[0]), dtype=np.uint8)
            cv2.putText(canvas, l, (5, 22), font, 0.7, 255, 2, cv2.LINE_AA)
            self.templates["letters"][l] = canvas

        # 省份模板使用拼音首字母代替 (演示用)
        self.templates["provinces"] = {}
        province_pinyin = {
            "京": "B", "沪": "S", "津": "T", "渝": "C", "冀": "H",
            "晋": "J", "蒙": "M", "辽": "L", "吉": "J", "黑": "H",
            "苏": "S", "浙": "Z", "皖": "W", "闽": "F", "赣": "G",
            "鲁": "S", "豫": "Y", "鄂": "E", "湘": "X", "粤": "G",
            "桂": "G", "琼": "Q", "川": "S", "贵": "G", "云": "Y",
            "藏": "Z", "陕": "S", "甘": "G", "青": "Q", "宁": "N", "新": "X",
        }
        for p, py in province_pinyin.items():
            canvas = np.zeros((size[1], size[0]), dtype=np.uint8)
            cv2.putText(canvas, py, (5, 22), font, 0.7, 255, 2, cv2.LINE_AA)
            self.templates["provinces"][p] = canvas

    @timer
    def _load_svm(self):
        """加载 SVM 模型"""
        model_path = self.config["svm_model_path"]
        if os.path.exists(model_path):
            with open(model_path, "rb") as f:
                self.svm_model = pickle.load(f)

    @timer
    def _load_cnn(self):
        """加载 CNN 模型"""
        try:
            import torch
            model_path = self.config["cnn_model_path"]
            if os.path.exists(model_path):
                self.cnn_model = SimpleCharCNN(num_classes=NUM_CLASSES)
                self.cnn_model.load_state_dict(
                    torch.load(model_path, map_location="cpu")
                )
                self.cnn_model.eval()
        except ImportError:
            print("Warning: PyTorch not installed, CNN method unavailable")
            self.cnn_model = None

    @timer
    def recognize_template(self, char_image, position=0):
        """
        模板匹配识别

        参数:
            char_image: 标准化字符图像 (20x28 二值化)
            position: 字符位置 (0=省份, 1=字母, 2+=字母或数字)
        返回:
            (char, confidence)
        """
        # 确保输入是二值图
        if len(char_image.shape) == 3:
            char_image = cv2.cvtColor(char_image, cv2.COLOR_BGR2GRAY)
        _, char_image = cv2.threshold(char_image, 127, 255, cv2.THRESH_BINARY)

        # 根据位置选择候选字符集
        if position == 0:
            candidates = self.templates.get("provinces", {})
        elif position == 1:
            candidates = self.templates.get("letters", {})
        else:
            candidates = {}
            candidates.update(self.templates.get("letters", {}))
            candidates.update(self.templates.get("digits", {}))

        if not candidates:
            return "?", 0.0

        # 遍历所有模板，计算匹配度
        best_char = "?"
        best_score = -1
        method = eval(self.config["template_match_method"])

        for char, template in candidates.items():
            # 确保尺寸一致
            if char_image.shape != template.shape:
                template = cv2.resize(template, (char_image.shape[1], char_image.shape[0]))

            result = cv2.matchTemplate(char_image, template, method)
            score = float(result[0, 0])

            if score > best_score:
                best_score = score
                best_char = char

        # 归一化置信度到 [0, 1]
        confidence = max(0.0, min(1.0, best_score))

        return best_char, confidence

    @timer
    def recognize_svm(self, char_image, position=0):
        """SVM 字符识别 (需要先训练 SVM 模型)"""
        if self.svm_model is None:
            return self.recognize_template(char_image, position)

        # 特征提取: HOG + 像素特征
        features = self._extract_features(char_image)

        # 预测
        label = self.svm_model.predict([features])[0]
        char_map = build_char_map(self.config)
        char = char_map.get(int(label), "?")

        # 尝试获取概率
        confidence = 1.0
        if hasattr(self.svm_model, "predict_proba"):
            probs = self.svm_model.predict_proba([features])[0]
            confidence = float(probs[int(label)])

        return char, confidence

    @timer
    def recognize_cnn(self, char_image, position=0):
        """CNN 字符识别 (需要先训练 CNN 模型)"""
        if self.cnn_model is None:
            return self.recognize_template(char_image, position)

        import torch

        # 预处理
        img = char_image.astype(np.float32) / 255.0
        if len(img.shape) == 2:
            img = np.stack([img] * 3, axis=0)
        else:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = np.transpose(img, (2, 0, 1))

        tensor = torch.FloatTensor(img).unsqueeze(0)

        with torch.no_grad():
            output = self.cnn_model(tensor)
            probs = torch.softmax(output, dim=1)
            confidence, pred = torch.max(probs, 1)
            label = pred.item()
            conf = confidence.item()

        char_map = build_char_map(self.config)
        char = char_map.get(label, "?")
        return char, conf

    def _extract_features(self, char_image):
        """
        特征提取 (用于 SVM)
        HOG 特征 + 统计特征
        """
        # 确保是灰度图
        if len(char_image.shape) == 3:
            char_image = cv2.cvtColor(char_image, cv2.COLOR_BGR2GRAY)

        # HOG 特征
        win_size = (20, 28)
        if char_image.shape != win_size[::-1]:
            char_image = cv2.resize(char_image, win_size)

        hog = cv2.HOGDescriptor(
            _winSize=(20, 28),
            _blockSize=(10, 14),
            _blockStride=(5, 7),
            _cellSize=(5, 7),
            _nbins=9,
        )
        hog_features = hog.compute(char_image).flatten()

        # 像素特征 (降采样)
        small = cv2.resize(char_image, (10, 14)).flatten()
        pixel_features = small.astype(np.float32) / 255.0

        return np.concatenate([hog_features, pixel_features])

    def recognize(self, char_image, position=0):
        """
        字符识别主函数

        参数:
            char_image: 标准化字符图像
            position: 字符位置 (0=省份, 1=字母, 2+=字母或数字)
        返回:
            (char, confidence)
        """
        if self.method == "svm":
            return self.recognize_svm(char_image, position)
        elif self.method == "cnn":
            return self.recognize_cnn(char_image, position)
        else:
            return self.recognize_template(char_image, position)

    def recognize_all(self, char_images):
        """
        批量识别字符

        参数:
            char_images: 字符图像列表
        返回:
            (plate_text, details, avg_confidence, timing)
        """
        self._timings = {}
        import time

        results = []
        details = []
        confidences = []

        for i, char_img in enumerate(char_images):
            start = time.perf_counter()
            char, conf = self.recognize(char_img, position=i)
            elapsed = (time.perf_counter() - start) * 1000

            results.append(char)
            confidences.append(conf)
            details.append({
                "position": i,
                "char": char,
                "confidence": conf,
                "timing": elapsed,
            })

        plate_text = "".join(results)
        avg_conf = float(np.mean(confidences)) if confidences else 0.0

        return plate_text, details, avg_conf, dict(self._timings)


class SimpleCharCNN:
    """
    简单 CNN 字符识别网络 (PyTorch)
    结构: Conv -> Pool -> Conv -> Pool -> FC -> FC
    输入: 3 x 28 x 20 (RGB)
    输出: 65 类 (31省 + 24字母 + 10数字)
    """

    def __init__(self, num_classes=NUM_CLASSES):
        import torch.nn as nn

        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),               # 14x10
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),               # 7x5
        )

        self.classifier = nn.Sequential(
            nn.Linear(64 * 7 * 5, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, num_classes),
        )

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x
