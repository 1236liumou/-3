"""
全局配置文件
集中管理所有可调参数，方便实验对比和调优
"""

import os
from pathlib import Path

# ============================================================
# 路径配置
# ============================================================
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
TEMPLATE_DIR = DATA_DIR / "templates"      # 字符模板目录
TEST_IMAGES_DIR = DATA_DIR / "test_images"  # 测试图像目录

# ============================================================
# Stage 1: 图像预处理参数
# ============================================================
PREPROCESS_CONFIG = {
    "gaussian_blur_kernel": (5, 5),   # 高斯模糊核大小
    "gaussian_sigma": 0,               # 高斯模糊标准差 (0=自动计算)
    "clahe_clip_limit": 2.0,           # CLAHE 对比度限制
    "clahe_grid_size": (8, 8),         # CLAHE 网格大小
    "bilateral_d": 9,                  # 双边滤波邻域直径
    "bilateral_sigma_color": 75,       # 双边滤波颜色空间标准差
    "bilateral_sigma_space": 75,       # 双边滤波坐标空间标准差
}

# ============================================================
# Stage 2: 车牌定位参数
# ============================================================
PLATE_LOCATOR_CONFIG = {
    # 车牌颜色范围 (HSV 空间)
    # 提高饱和度下限到 80，过滤深色背景 (如深蓝车身)
    # 蓝牌
    "blue_lower": (100, 80, 80),
    "blue_upper": (124, 255, 255),
    # 绿牌 (新能源)
    "green_lower": (35, 80, 80),
    "green_upper": (99, 255, 255),
    # 黄牌
    "yellow_lower": (15, 80, 80),
    "yellow_upper": (34, 255, 255),

    # 形态学操作
    "morph_kernel_size": (25, 10),     # 形态学闭操作核大小
    "morph_iterations": 2,             # 形态学迭代次数

    # 轮廓筛选条件
    "min_plate_area": 1500,            # 最小车牌面积
    "max_plate_area": 50000,           # 最大车牌面积
    "min_aspect_ratio": 1.5,           # 最小宽高比 (车牌宽/高)
    "max_aspect_ratio": 6.0,           # 最大宽高比
    "min_rect_score": 0.3,             # 最小矩形度 (轮廓面积/外接矩形面积)

    # 边缘检测 (备选方案)
    "canny_threshold1": 50,
    "canny_threshold2": 150,
}

# ============================================================
# Stage 3: 倾斜校正参数
# ============================================================
SKEW_CORRECTION_CONFIG = {
    "hough_rho": 1,                    # Hough 变换距离精度
    "hough_theta": 3.14159265358979 / 180,  # 角度精度 (1度)
    "hough_threshold": 30,             # Hough 累加器阈值
    "min_line_length": 20,             # 最小线段长度
    "max_line_gap": 5,                 # 最大线段间隙
    "max_skew_angle": 20.0,            # 最大校正角度 (度)
    "enable": True,                     # 是否启用倾斜校正
}

# ============================================================
# Stage 4: 字符分割参数
# ============================================================
CHAR_SEGMENTATION_CONFIG = {
    "resize_width": 240,               # 车牌标准化宽度
    "resize_height": 80,               # 车牌标准化高度
    "binary_threshold": 0,             # 二值化阈值 (0=自适应)
    "morph_close_kernel": (3, 3),      # 字符形态学核
    "projection_threshold_ratio": 0.15, # 投影法阈值比例
    "min_char_width": 6,               # 最小字符宽度
    "max_char_width": 50,              # 最大字符宽度
    "min_char_height": 15,             # 最小字符高度
    "char_resize": (20, 28),           # 字符标准化大小 (宽, 高)
    "remove_border": True,             # 是否去除车牌边框
    "border_margin_ratio": 0.15,       # 边框裁剪比例 (加大以去除 padding)
}

# ============================================================
# Stage 5: 字符识别参数
# ============================================================
CHAR_RECOGNITION_CONFIG = {
    # 识别方法: "template" | "svm" | "cnn"
    "method": "template",

    # 字符集 (中国车牌)
    # 省份简称 (第一个字符)
    "provinces": [
        "京", "沪", "津", "渝", "冀", "晋", "蒙", "辽", "吉", "黑",
        "苏", "浙", "皖", "闽", "赣", "鲁", "豫", "鄂", "湘", "粤",
        "桂", "琼", "川", "贵", "云", "藏", "陕", "甘", "青", "宁", "新",
    ],
    # 字母 (第二个字符)
    # 数字+字母 (后续字符)
    "digits": list("0123456789"),
    "letters": list("ABCDEFGHJKLMNPQRSTUVWXYZ"),  # 车牌不使用 I 和 O

    # 模板匹配参数
    "template_match_method": "cv2.TM_CCOEFF_NORMED",

    # SVM 参数
    "svm_kernel": "RBF",
    "svm_C": 10.0,
    "svm_gamma": "scale",
    "svm_model_path": "models/svm_model.pkl",

    # CNN 参数
    "cnn_model_path": "models/cnn_model.pth",
    "cnn_input_size": (20, 28),  # (宽, 高) — 与 char_resize 一致
}

# ============================================================
# Streamlit 界面配置
# ============================================================
APP_CONFIG = {
    "page_title": "车牌识别系统",
    "page_icon": "🚗",
    "layout": "wide",
    "max_upload_size_mb": 10,
    "supported_formats": ["png", "jpg", "jpeg", "bmp", "webp", "tiff"],
}

# 确保输出目录存在
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
