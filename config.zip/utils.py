"""
工具函数模块
提供图像处理辅助功能和可视化功能
"""

import cv2
import numpy as np
import os
import time
from functools import wraps


def imwrite_unicode(path, image):
    """
    Unicode 安全的图像写入 (cv2.imwrite 不支持中文路径)
    使用 imencode + 文件写入绕过限制
    """
    ext = os.path.splitext(path)[1]
    result, encoded = cv2.imencode(ext, image)
    if result:
        with open(path, 'wb') as f:
            f.write(encoded.tobytes())
        return True
    return False


def imread_unicode(path, flags=cv2.IMREAD_COLOR):
    """
    Unicode 安全的图像读取 (cv2.imread 不支持中文路径)
    """
    try:
        with open(path, 'rb') as f:
            data = f.read()
        return cv2.imdecode(np.frombuffer(data, dtype=np.uint8), flags)
    except Exception:
        return None


def timer(func):
    """
    计时装饰器 (非侵入式)
    不修改返回值，计时结果存储在实例的 _timings 字典中
    需要在类的 __init__ 中初始化 self._timings = {}
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = (time.perf_counter() - start) * 1000
        # 存储到实例的 _timings 字典
        if args and hasattr(args[0], '_timings'):
            args[0]._timings[func.__name__] = elapsed
        return result
    return wrapper


def to_gray(image):
    """BGR 转灰度图，如果已经是灰度图则直接返回"""
    if len(image.shape) == 3:
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return image.copy()


def to_hsv(image):
    """BGR 转 HSV"""
    return cv2.cvtColor(image, cv2.COLOR_BGR2HSV)


def resize_with_ratio(image, width=None, height=None, inter=cv2.INTER_AREA):
    """
    按比例缩放图像，保持宽高比
    只指定 width 或 height 其中一个即可
    """
    h, w = image.shape[:2]
    if width is None and height is None:
        return image
    if width is None:
        ratio = height / float(h)
        dim = (int(w * ratio), height)
    else:
        ratio = width / float(w)
        dim = (width, int(h * ratio))
    return cv2.resize(image, dim, interpolation=inter)


def order_points(pts):
    """
    对四个点排序: [左上, 右上, 右下, 左下]
    用于透视变换前的点对齐
    """
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]   # 左上: 和最小
    rect[2] = pts[np.argmax(s)]   # 右下: 和最大
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]  # 右上: 差最小
    rect[3] = pts[np.argmax(diff)]  # 左下: 差最大
    return rect


def four_point_transform(image, pts):
    """
    四点透视变换，将倾斜的车牌区域校正为矩形
    """
    rect = order_points(pts)
    tl, tr, br, bl = rect

    # 计算新图像的宽度
    width_a = np.sqrt((br[0] - bl[0]) ** 2 + (br[1] - bl[1]) ** 2)
    width_b = np.sqrt((tr[0] - tl[0]) ** 2 + (tr[1] - tl[1]) ** 2)
    max_width = max(int(width_a), int(width_b))

    # 计算新图像的高度
    height_a = np.sqrt((tr[0] - br[0]) ** 2 + (tr[1] - br[1]) ** 2)
    height_b = np.sqrt((tl[0] - bl[0]) ** 2 + (tl[1] - bl[1]) ** 2)
    max_height = max(int(height_a), int(height_b))

    dst = np.array([
        [0, 0],
        [max_width - 1, 0],
        [max_width - 1, max_height - 1],
        [0, max_height - 1]
    ], dtype="float32")

    m = cv2.getPerspectiveTransform(rect, dst)
    warped = cv2.warpPerspective(image, m, (max_width, max_height))
    return warped


def calculate_iou(box1, box2):
    """计算两个矩形的 IoU (交并比)"""
    x1 = max(box1[0], box2[0])
    y1 = max(box1[1], box2[1])
    x2 = min(box1[2], box2[2])
    y2 = min(box1[3], box2[3])

    inter = max(0, x2 - x1) * max(0, y2 - y1)
    area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
    area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
    union = area1 + area2 - inter

    return inter / union if union > 0 else 0


def non_max_suppression(boxes, scores, iou_threshold=0.3):
    """非极大值抑制，去除重叠的候选框"""
    if len(boxes) == 0:
        return []

    boxes = np.array(boxes, dtype="float32")
    scores = np.array(scores)

    x1 = boxes[:, 0]
    y1 = boxes[:, 1]
    x2 = boxes[:, 2]
    y2 = boxes[:, 3]

    areas = (x2 - x1) * (y2 - y1)
    order = scores.argsort()[::-1]

    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])

        w = np.maximum(0, xx2 - xx1)
        h = np.maximum(0, yy2 - yy1)
        inter = w * h
        ovr = inter / (areas[i] + areas[order[1:]] - inter)

        inds = np.where(ovr <= iou_threshold)[0]
        order = order[inds + 1]

    return keep


def draw_results(image, plate_box, plate_text, char_boxes=None):
    """
    在原图上绘制识别结果
    plate_box: (x, y, w, h)
    plate_text: 识别出的车牌字符串
    char_boxes: 字符位置列表 [(x, y, w, h), ...]
    使用 PIL 渲染中文车牌号 (OpenCV 不支持中文)
    """
    result = image.copy()
    x, y, w, h = plate_box

    # 画车牌框
    cv2.rectangle(result, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # 画字符框 (如果提供)
    if char_boxes:
        for cx, cy, cw, ch in char_boxes:
            cv2.rectangle(result,
                          (x + cx, y + cy),
                          (x + cx + cw, y + cy + ch),
                          (0, 200, 255), 1)

    # 写车牌号 (使用 PIL 支持中文)
    label = plate_text if plate_text else "Unknown"

    # 尝试加载中文字体
    from PIL import ImageFont, ImageDraw, Image
    font_paths = [
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simsun.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/System/Library/Fonts/PingFang.ttc",
    ]
    font = None
    font_size = max(16, int(h * 0.3))
    for fp in font_paths:
        if os.path.exists(fp):
            try:
                font = ImageFont.truetype(fp, font_size)
                break
            except Exception:
                continue

    # 将 OpenCV 图像转为 PIL 绘制文字
    pil_img = Image.fromarray(cv2.cvtColor(result, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_img)

    # 计算文字大小
    if font:
        bbox = draw.textbbox((0, 0), label, font=font)
        text_w = bbox[2] - bbox[0]
        text_h = bbox[3] - bbox[1]
    else:
        # 退回英文字体
        font = ImageFont.load_default()
        bbox = draw.textbbox((0,0), label, font=font)
        text_w = bbox[2] - bbox[0]
        text_h = bbox[3] - bbox[1]

    # 绘制背景矩形 + 文字
    label_x = x
    label_y = max(0, y - text_h - 8)
    draw.rectangle(
        [label_x, label_y, label_x + text_w + 8, label_y + text_h + 6],
        fill=(0, 255, 0),
    )
    draw.text((label_x + 4, label_y + 2), label, fill=(0, 0, 0), font=font)

    # 转回 OpenCV 格式
    result = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
    return result


def validate_plate_format(plate_text):
    """
    车牌格式校验
    标准格式: 省份(1) + 字母(1) + 字母或数字(5)  如: 京A12345
    新能源:  省份(1) + 字母(1) + 字母或数字(6)  如: 京AD12345
    """
    if not plate_text or len(plate_text) < 7:
        return False

    provinces = list("京津沪渝冀晋蒙辽吉黑苏浙皖闽赣鲁豫鄂湘粤桂琼川贵云藏陕甘青宁新")
    if plate_text[0] not in provinces:
        return False

    letters = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    if plate_text[1] not in letters:
        return False

    valid_chars = "0123456789ABCDEFGHJKLMNPQRSTUVWXYZ"
    for c in plate_text[2:]:
        if c not in valid_chars:
            return False

    return True


def parse_ccpd_filename(filename):
    """
    解析 CCPD 数据集文件名
    CCPD 标注信息编码在文件名中，格式:
    025-95_113-154&383_386&473-386&473_177&454_154&383_363&402-0_0_22_27_27_33_16-37-15.jpg

    各字段含义 (以 - 分隔):
    1. 面积比: 025
    2. 倾斜度: 95
    3. 边界框坐标: 113-154&383_386&473 (x1_y1_x2_y2)
    4. 四角坐标: 386&473_177&454_154&383_363&402 (左下_右下_右上_左上)
    5. 车牌号: 0_0_22_27_27_33_16 (映射到字符)
    6. 亮度: 37
    7. 模糊度: 15

    车牌号映射字典:
    """
    # CCPD 字符索引到字符的映射
    ccpd_chars = (
        list("京津沪渝冀晋蒙辽吉黑苏浙皖闽赣鲁豫鄂湘粤桂琼川贵云藏陕甘青宁新")
        + list("0123456789")
        + list("ABCDEFGHJKLMNPQRSTUVWXYZ")  # 车牌不含 I, O
    )

    parts = filename.replace(".jpg", "").split("-")
    if len(parts) < 5:
        return None

    try:
        # 边界框
        bbox_str = parts[2]
        x1_y1, x2_y2 = bbox_str.split("_")
        x1, y1 = map(int, x1_y1.split("&"))
        x2, y2 = map(int, x2_y2.split("&"))

        # 四角点
        corners_str = parts[3]
        corner_pts = []
        for pt_str in corners_str.split("_"):
            px, py = map(int, pt_str.split("&"))
            corner_pts.append([px, py])

        # 车牌号
        plate_indices = list(map(int, parts[4].split("_")))
        plate_text = "".join([ccpd_chars[i] for i in plate_indices])

        # 亮度和模糊度
        brightness = int(parts[5]) if len(parts) > 5 else 0
        blurriness = int(parts[6]) if len(parts) > 6 else 0

        return {
            "bbox": (x1, y1, x2, y2),
            "corners": corner_pts,
            "plate_text": plate_text,
            "brightness": brightness,
            "blurriness": blurriness,
            "area_ratio": int(parts[0]),
            "tilt": int(parts[1]),
        }
    except (ValueError, IndexError):
        return None
