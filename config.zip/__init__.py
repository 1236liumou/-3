"""
车牌识别系统 (License Plate Recognition System)
数字图像处理课程设计项目
"""

__version__ = "1.0.0"
__author__ = "Course Design"
