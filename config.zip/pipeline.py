"""
端到端车牌识别流水线
支持两种引擎:
  1. "hyperlpr" — HyperLPR3 AI 引擎 (高精度，端到端)
  2. "traditional" — 传统图像处理五阶段 (课程设计演示)

使用方式:
    from lpr.pipeline import LPRPipeline

    # AI 高精度模式
    pipeline = LPRPipeline(engine="hyperlpr")
    result = pipeline.recognize(image)

    # 传统 CV 模式 (课程演示)
    pipeline = LPRPipeline(engine="traditional")
    result = pipeline.recognize(image)
"""

import os
import cv2
import numpy as np
import time

# 设置 HyperLPR3 模型目录
os.environ.setdefault(
    "HYPERLPR3_HOME",
    os.path.join(os.path.expanduser("~"), ".hyperlpr3"),
)

from .preprocess import ImagePreprocessor
from .plate_locator import PlateLocator
from .skew_correction import SkewCorrector
from .char_segmentation import CharSegmenter
from .char_recognition import CharRecognizer
from .utils import (
    draw_results, validate_plate_format, resize_with_ratio, imread_unicode,
    to_gray,
)


class LPRPipeline:
    """车牌识别流水线 — 双引擎架构"""

    def __init__(self,
                 engine="hyperlpr",
                 locate_method="multi",
                 segment_method="projection",
                 recognize_method="template",
                 verbose=False):
        """
        参数:
            engine:           "hyperlpr" (AI引擎, 默认) | "traditional" (传统CV)
            locate_method:    传统模式: "color" | "edge" | "multi"
            segment_method:   传统模式: "projection" | "connected"
            recognize_method: 传统模式: "template" | "svm" | "cnn"
            verbose: 是否打印详细过程信息
        """
        self.engine = engine
        self.locate_method = locate_method
        self.segment_method = segment_method
        self.recognize_method = recognize_method
        self.verbose = verbose

        # 传统 CV 模块 (延迟初始化)
        self._preprocessor = None
        self._locator = None
        self._corrector = None
        self._segmenter = None
        self._recognizer = None

        # HyperLPR3 引擎 (延迟初始化)
        self._catcher = None

    @property
    def preprocessor(self):
        if self._preprocessor is None:
            self._preprocessor = ImagePreprocessor()
        return self._preprocessor

    @property
    def locator(self):
        if self._locator is None:
            self._locator = PlateLocator()
        return self._locator

    @property
    def corrector(self):
        if self._corrector is None:
            self._corrector = SkewCorrector()
        return self._corrector

    @property
    def segmenter(self):
        if self._segmenter is None:
            self._segmenter = CharSegmenter()
        return self._segmenter

    @property
    def recognizer(self):
        if self._recognizer is None:
            from .config import CHAR_RECOGNITION_CONFIG
            config = CHAR_RECOGNITION_CONFIG.copy()
            config["method"] = self.recognize_method
            self._recognizer = CharRecognizer(config=config)
        return self._recognizer

    @property
    def catcher(self):
        """HyperLPR3 引擎实例 (延迟加载)"""
        if self._catcher is None:
            from hyperlpr3 import LicensePlateCatcher
            self._catcher = LicensePlateCatcher()
            self._log("HyperLPR3 引擎已加载")
        return self._catcher

    def _log(self, msg):
        if self.verbose:
            print(f"  [Pipeline] {msg}")

    # ================================================================
    #  公共接口
    # ================================================================

    def recognize(self, image_input):
        """
        端到端车牌识别

        参数:
            image_input: 图像路径(str) 或 numpy 数组

        返回:
            dict: {
                "success": 是否成功,
                "plate_text": 车牌字符串,
                "confidence": 置信度,
                "is_valid": 格式是否合法,
                "plate_image": 车牌区域图像,
                "corrected_image": 校正后图像,
                "char_images": 字符图像列表,
                "result_image": 标注结果图,
                "stage_details": 各阶段详细信息,
                "timing_summary": 各阶段耗时,
                "total_time": 总耗时,
                "error": 错误信息,
                "engine": 使用的引擎,
                "all_plates": 所有检测到的车牌 (Hyperlpr 模式),
            }
        """
        total_start = time.perf_counter()

        # 加载图像
        if isinstance(image_input, str):
            image = imread_unicode(image_input)
            if image is None:
                return self._error_result(f"无法加载图像: {image_input}")
        else:
            image = image_input.copy()

        # 缩放过大图像
        max_width = 1280
        if image.shape[1] > max_width:
            image = resize_with_ratio(image, width=max_width)

        self._log(f"图像尺寸: {image.shape[1]}x{image.shape[0]}, 引擎: {self.engine}")

        if self.engine == "hyperlpr":
            result = self._recognize_hyperlpr(image)
        else:
            result = self._recognize_traditional(image)

        result["total_time"] = (time.perf_counter() - total_start) * 1000
        result["engine"] = self.engine
        return result

    # ================================================================
    #  HyperLPR3 AI 引擎
    # ================================================================

    def _recognize_hyperlpr(self, image):
        """使用 HyperLPR3 进行端到端识别"""
        result = self._empty_result()

        try:
            t0 = time.perf_counter()
            plates = self.catcher(image)
            t1 = time.perf_counter()

            result["timing_summary"]["hyperlpr_total"] = (t1 - t0) * 1000
            result["stage_details"]["hyperlpr"] = {
                "num_detected": len(plates),
                "timing": (t1 - t0) * 1000,
            }

            if not plates:
                result["error"] = "未检测到车牌"
                return result

            # 所有检测结果
            # HyperLPR3 返回格式: [plate_text, confidence, plate_type, bbox]
            # bbox = [x1, y1, x2, y2] (矩形坐标)
            plate_type_names = {0: "蓝牌", 1: "黄牌", 2: "绿牌(新能源)",
                                3: "白牌", 4: "黑牌", 5: "黄绿牌"}
            all_plates = []
            for item in plates:
                p_text = item[0]
                p_conf = float(item[1])
                p_type = int(item[2]) if len(item) > 2 else 0
                p_bbox = item[3] if len(item) > 3 else item[2]
                all_plates.append({
                    "plate_text": p_text,
                    "confidence": p_conf,
                    "plate_type": plate_type_names.get(p_type, f"类型{p_type}"),
                    "bbox": p_bbox,
                })
            result["all_plates"] = all_plates

            # 取置信度最高的
            best = max(plates, key=lambda x: x[1])
            best_text = best[0]
            best_conf = float(best[1])
            best_bbox = best[3] if len(best) > 3 else best[2]

            result["plate_text"] = best_text
            result["confidence"] = best_conf
            result["is_valid"] = validate_plate_format(best_text)
            result["success"] = True

            # 截取车牌区域图像
            # bbox 格式: [x1, y1, x2, y2]
            if isinstance(best_bbox[0], (list, tuple)):
                # 四角点格式
                xs = [p[0] for p in best_bbox]
                ys = [p[1] for p in best_bbox]
                x1, y1 = int(min(xs)), int(min(ys))
                x2, y2 = int(max(xs)), int(max(ys))
            else:
                # 矩形格式 [x1, y1, x2, y2]
                x1, y1, x2, y2 = int(best_bbox[0]), int(best_bbox[1]), \
                                  int(best_bbox[2]), int(best_bbox[3])

            # 稍微扩展
            pad = max(x2 - x1, y2 - y1) // 10
            x1 = max(0, x1 - pad)
            y1 = max(0, y1 - pad)
            x2 = min(image.shape[1], x2 + pad)
            y2 = min(image.shape[0], y2 + pad)
            result["plate_image"] = image[y1:y2, x1:x2].copy()
            result["plate_box"] = (x1, y1, x2 - x1, y2 - y1)

            # 绘制结果图
            result["result_image"] = draw_results(
                image, result["plate_box"], best_text, None
            )

            self._log(
                f"HyperLPR3: {best_text} (conf={best_conf:.2%}), "
                f"共检测到 {len(plates)} 个车牌"
            )

        except Exception as e:
            result["error"] = f"HyperLPR3 错误: {e}"
            import traceback
            traceback.print_exc()

        return result

    # ================================================================
    #  传统 CV 五阶段
    # ================================================================

    def _recognize_traditional(self, image):
        """传统图像处理五阶段流水线"""
        result = self._empty_result()

        try:
            # ============================================================
            # Stage 1: 图像预处理
            # ============================================================
            self._log("Stage 1: 图像预处理...")
            preprocess_result = self.preprocessor.process(image)
            result["stage_details"]["preprocess"] = {
                "has_gray": preprocess_result["gray"] is not None,
                "has_enhanced": preprocess_result["enhanced"] is not None,
                "timing": preprocess_result["timing"],
            }
            result["timing_summary"]["preprocess"] = sum(
                preprocess_result["timing"].values()
            )

            # ============================================================
            # Stage 2: 车牌定位
            # ============================================================
            self._log("Stage 2: 车牌定位...")
            locate_result = self.locator.locate(
                preprocess_result["color"],
                preprocess_result["gray"],
                method=self.locate_method,
            )

            plate_region = locate_result["plate_region"]
            if plate_region is None:
                result["error"] = "未检测到车牌区域"
                return result

            result["stage_details"]["locate"] = {
                "method": locate_result["method"],
                "num_candidates": len(locate_result["all_candidates"]),
                "plate_region": {
                    "rect": plate_region["rect"],
                    "score": plate_region.get("score", 0),
                    "area": plate_region["area"],
                    "aspect_ratio": plate_region["aspect_ratio"],
                },
                "timing": locate_result["timing"],
            }
            result["timing_summary"]["locate"] = sum(
                locate_result["timing"].values()
            )

            # 截取车牌区域
            x, y, w, h = plate_region["rect"]
            pad = max(w, h) // 10
            x1 = max(0, x - pad)
            y1 = max(0, y - pad)
            x2 = min(image.shape[1], x + w + pad)
            y2 = min(image.shape[0], y + h + pad)
            plate_image = image[y1:y2, x1:x2].copy()

            result["plate_image"] = plate_image
            result["plate_box"] = (x1, y1, x2 - x1, y2 - y1)
            self._log(f"  车牌区域: ({x}, {y}, {w}, {h})")

            # ============================================================
            # Stage 3: 倾斜校正
            # ============================================================
            self._log("Stage 3: 倾斜校正...")
            corrected_image, skew_angle, skew_timing = self.corrector.correct(
                plate_image, plate_region, method="hough"
            )
            result["corrected_image"] = corrected_image
            result["stage_details"]["skew_correction"] = {
                "skew_angle": skew_angle,
                "timing": skew_timing,
            }
            result["timing_summary"]["skew_correction"] = sum(
                skew_timing.values()
            ) if skew_timing else 0

            # ============================================================
            # Stage 4: 字符分割
            # ============================================================
            self._log("Stage 4: 字符分割...")
            segment_result = self.segmenter.segment(
                corrected_image, method=self.segment_method
            )
            result["char_images"] = segment_result["chars"]
            result["stage_details"]["segment"] = {
                "method": self.segment_method,
                "method_used": segment_result.get("method_used", self.segment_method),
                "num_chars": segment_result["num_chars"],
                "char_boxes": segment_result["char_boxes"],
                "timing": segment_result["timing"],
            }
            result["timing_summary"]["segment"] = sum(
                segment_result["timing"].values()
            )
            self._log(f"  分割字符数: {segment_result['num_chars']}")

            # ============================================================
            # Stage 5: 字符识别
            # ============================================================
            self._log("Stage 5: 字符识别...")
            if segment_result["chars"]:
                plate_text, char_details, avg_conf, rec_timing = (
                    self.recognizer.recognize_all(segment_result["chars"])
                )
            else:
                plate_text, char_details, avg_conf = "", [], 0.0

            result["plate_text"] = plate_text
            result["confidence"] = avg_conf
            result["is_valid"] = validate_plate_format(plate_text)
            result["stage_details"]["recognize"] = {
                "method": self.recognizer.method,
                "char_details": char_details,
            }
            result["timing_summary"]["recognize"] = sum(
                d["timing"] for d in char_details
            ) if char_details else 0
            self._log(f"  识别结果: {plate_text} (conf={avg_conf:.2%})")

            # 绘制结果
            result["result_image"] = draw_results(
                image, result["plate_box"], plate_text, None
            )
            result["success"] = True

        except Exception as e:
            result["error"] = str(e)
            import traceback
            traceback.print_exc()

        return result

    # ================================================================
    #  辅助方法
    # ================================================================

    def _empty_result(self):
        return {
            "success": False,
            "plate_text": "",
            "confidence": 0.0,
            "is_valid": False,
            "plate_image": None,
            "corrected_image": None,
            "char_images": [],
            "result_image": None,
            "stage_details": {},
            "timing_summary": {},
            "total_time": 0,
            "error": None,
            "engine": self.engine,
            "all_plates": [],
        }

    def _error_result(self, msg):
        r = self._empty_result()
        r["error"] = msg
        return r

    def recognize_batch(self, image_paths, progress_callback=None):
        """批量识别"""
        results = []
        total = len(image_paths)
        for i, path in enumerate(image_paths):
            result = self.recognize(path)
            results.append(result)
            if progress_callback:
                progress_callback(i + 1, total, result)
        return results
