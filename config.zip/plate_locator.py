"""
Stage 2: 车牌定位模块
从车辆图像中定位车牌区域

核心思路:
  方案A (颜色+形态学): HSV颜色空间过滤 -> 形态学闭操作 -> 轮廓检测 -> 筛选
  方案B (边缘+形态学):  Sobel边缘 -> 形态学闭操作 -> 轮廓检测 -> 筛选
  方案C (级联检测器):  Haar级联分类器 (需预训练模型)

默认使用方案A，适合中国蓝牌/绿牌/黄牌
"""

import cv2
import numpy as np
from .config import PLATE_LOCATOR_CONFIG
from .utils import timer, to_hsv, non_max_suppression


class PlateLocator:
    """车牌定位器"""

    def __init__(self, config=None):
        self.config = config or PLATE_LOCATOR_CONFIG
        self._timings = {}
        self.cascade = None

    @timer
    def color_filter(self, hsv_image, plate_type="blue"):
        """
        HSV 颜色空间过滤
        根据车牌类型提取对应颜色区域

        参数:
            hsv_image: HSV 格式图像
            plate_type: "blue" | "green" | "yellow"
        返回:
            mask: 颜色掩码 (二值图)
        """
        lower_key = f"{plate_type}_lower"
        upper_key = f"{plate_type}_upper"

        lower = np.array(self.config[lower_key])
        upper = np.array(self.config[upper_key])

        mask = cv2.inRange(hsv_image, lower, upper)

        # 形态学开操作去噪
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)

        return mask

    @timer
    def color_filter_multi(self, hsv_image):
        """
        多颜色联合过滤 (蓝+绿+黄)
        适应不同类型车牌的检测需求
        """
        masks = []
        for plate_type in ["blue", "green", "yellow"]:
            mask = self.color_filter(hsv_image, plate_type)
            masks.append(mask)
        combined = cv2.bitwise_or(masks[0], masks[1])
        combined = cv2.bitwise_or(combined, masks[2])
        return combined

    @timer
    def morphological_close(self, binary_image):
        """
        形态学闭操作
        连接相近区域，填充孔洞，形成连通区域
        使用宽矩形核 (水平方向连接字符区域)
        """
        kernel_size = self.config["morph_kernel_size"]
        iterations = self.config["morph_iterations"]
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, kernel_size)
        return cv2.morphologyEx(binary_image, cv2.MORPH_CLOSE, kernel,
                                iterations=iterations)

    @timer
    def sobel_edge(self, gray_image):
        """
        Sobel 边缘检测 (备选方案)
        水平方向梯度更显著 (车牌字符水平排列)
        """
        # x 方向 Sobel
        grad_x = cv2.Sobel(gray_image, cv2.CV_16S, 1, 0, ksize=3)
        grad_x = cv2.convertScaleAbs(grad_x)

        # 二值化
        _, binary = cv2.threshold(grad_x, 0, 255,
                                  cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        return binary

    @timer
    def canny_edge(self, gray_image):
        """Canny 边缘检测 (备选方案)"""
        t1 = self.config["canny_threshold1"]
        t2 = self.config["canny_threshold2"]
        return cv2.Canny(gray_image, t1, t2)

    @timer
    def find_plate_candidates(self, binary_image):
        """
        从二值图中检测轮廓并筛选车牌候选区域

        筛选条件:
        1. 面积在 [min_area, max_area] 范围内
        2. 宽高比在 [min_ratio, max_ratio] 范围内
        3. 矩形度 (轮廓面积/外接矩形面积) 大于阈值
        """
        contours, _ = cv2.findContours(binary_image,
                                       cv2.RETR_EXTERNAL,
                                       cv2.CHAIN_APPROX_SIMPLE)

        candidates = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area < self.config["min_plate_area"]:
                continue
            if area > self.config["max_plate_area"]:
                continue

            # 最小外接矩形 (可能旋转)
            rect = cv2.minAreaRect(contour)
            (cx, cy), (w, h), angle = rect

            # 确保宽 > 高
            if w < h:
                w, h = h, w

            # 宽高比筛选
            aspect_ratio = w / h if h > 0 else 0
            if aspect_ratio < self.config["min_aspect_ratio"]:
                continue
            if aspect_ratio > self.config["max_aspect_ratio"]:
                continue

            # 矩形度筛选
            rect_area = w * h
            rect_score = area / rect_area if rect_area > 0 else 0
            if rect_score < self.config["min_rect_score"]:
                continue

            # 获取旋转后的外接矩形四点
            box = cv2.boxPoints(rect)
            box = np.intp(box)

            # 同时保存正矩形坐标 (x, y, w, h)
            x, y, rw, rh = cv2.boundingRect(contour)

            candidates.append({
                "box": box,                    # 旋转四点 (用于倾斜校正)
                "rect": (x, y, rw, rh),        # 正矩形 (用于截取)
                "center": (int(cx), int(cy)),
                "size": (int(w), int(h)),
                "angle": angle,
                "area": area,
                "aspect_ratio": aspect_ratio,
                "rect_score": rect_score,
            })

        return candidates

    @timer
    def select_best_candidate(self, candidates):
        """
        从候选区域中选择最佳车牌位置
        评分标准: 矩形度 + 面积 + 宽高比接近标准值 (3.14)
        """
        if not candidates:
            return None

        best_score = -1
        best = None
        target_ratio = 3.14  # 标准中国车牌宽高比 (440mm / 140mm)

        for cand in candidates:
            # 宽高比接近度
            ratio_score = 1.0 - abs(cand["aspect_ratio"] - target_ratio) / target_ratio
            # 矩形度
            rect_score = cand["rect_score"]
            # 面积归一化 (越大越好，但有上限)
            area_score = min(cand["area"] / self.config["max_plate_area"], 1.0)

            # 综合评分
            score = ratio_score * 0.4 + rect_score * 0.3 + area_score * 0.3
            cand["score"] = score

            if score > best_score:
                best_score = score
                best = cand

        return best

    def locate(self, color_image, gray_image, method="multi"):
        """
        车牌定位主函数

        参数:
            color_image: 原始彩色图
            gray_image: 灰度图
            method: "color" (仅蓝牌) | "edge" (边缘法) | "multi" (逐颜色尝试取最佳)

        返回:
            dict: {
                "plate_region": 最优车牌区域信息,
                "all_candidates": 所有候选区域,
                "binary": 二值化中间结果,
                "method": 使用的方法,
                "timing": 耗时,
            }
        """
        self._timings = {}

        if method == "edge":
            # 边缘法
            mask = self.sobel_edge(gray_image)
            closed = self.morphological_close(mask)
            candidates = self.find_plate_candidates(closed)
            best = self.select_best_candidate(candidates)
            return {
                "plate_region": best,
                "all_candidates": candidates,
                "binary": closed,
                "method": method,
                "timing": dict(self._timings),
            }

        if method == "color":
            # 仅蓝牌
            hsv = to_hsv(color_image)
            mask = self.color_filter(hsv, "blue")
            closed = self.morphological_close(mask)
            candidates = self.find_plate_candidates(closed)
            best = self.select_best_candidate(candidates)
            return {
                "plate_region": best,
                "all_candidates": candidates,
                "binary": closed,
                "method": method,
                "timing": dict(self._timings),
            }

        # method == "multi": 逐颜色尝试，取最佳结果
        hsv = to_hsv(color_image)
        best_result = None
        best_score = -1
        all_candidates_combined = []
        best_binary = None
        best_color = None

        for plate_type in ["blue", "green", "yellow"]:
            mask = self.color_filter(hsv, plate_type)
            closed = self.morphological_close(mask)
            candidates = self.find_plate_candidates(closed)
            best = self.select_best_candidate(candidates)

            all_candidates_combined.extend(candidates)

            if best is not None:
                score = best.get("score", 0)
                if score > best_score:
                    best_score = score
                    best_result = best
                    best_binary = closed
                    best_color = plate_type

        return {
            "plate_region": best_result,
            "all_candidates": all_candidates_combined,
            "binary": best_binary if best_binary is not None else mask,
            "method": f"multi({best_color})" if best_color else "multi",
            "timing": dict(self._timings),
        }
