"""
Stage 3: 倾斜校正模块
对定位到的车牌进行倾斜校正，使其变为水平矩形
便于后续字符分割

核心方法:
  1. Hough 直线检测 -> 计算倾斜角度 -> 仿射变换旋转
  2. 最小外接矩形 -> 已知旋转角度 -> 仿射变换旋转
"""

import cv2
import numpy as np
from .config import SKEW_CORRECTION_CONFIG
from .utils import timer, four_point_transform


class SkewCorrector:
    """车牌倾斜校正器"""

    def __init__(self, config=None):
        self.config = config or SKEW_CORRECTION_CONFIG
        self._timings = {}

    @timer
    def correct_by_hough(self, plate_image, plate_region=None):
        """
        Hough 直线检测法倾斜校正

        流程:
        1. 灰度化 + 边缘检测
        2. Hough 直线检测
        3. 统计直线角度，计算平均倾斜角
        4. 仿射变换旋转校正

        参数:
            plate_image: 车牌区域图像
            plate_region: 车牌定位信息 (含 angle)
        返回:
            corrected: 校正后的图像
            angle: 校正角度
        """
        if len(plate_image.shape) == 3:
            gray = cv2.cvtColor(plate_image, cv2.COLOR_BGR2GRAY)
        else:
            gray = plate_image.copy()

        h, w = gray.shape[:2]

        # 边缘检测
        edges = cv2.Canny(gray, 50, 150)

        # Hough 直线检测
        lines = cv2.HoughLinesP(
            edges,
            rho=self.config["hough_rho"],
            theta=self.config["hough_theta"],
            threshold=self.config["hough_threshold"],
            minLineLength=self.config["min_line_length"],
            maxLineGap=self.config["max_line_gap"],
        )

        angles = []
        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                # 只考虑接近水平的线 (角度 < 45度)
                angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
                if abs(angle) < 45 or abs(angle) > 135:
                    # 归一化到 [-45, 45]
                    if angle > 90:
                        angle = angle - 180
                    elif angle < -90:
                        angle = angle + 180
                    angles.append(angle)

        if angles:
            skew_angle = np.median(angles)  # 中位数更鲁棒
        elif plate_region and "angle" in plate_region:
            skew_angle = plate_region["angle"]
            # minAreaRect 的角度规则: 当 w > h 时角度在 [-90, 0)
            if plate_region["size"][0] >= plate_region["size"][1]:
                if plate_region["angle"] < -45:
                    skew_angle = plate_region["angle"] + 90
        else:
            skew_angle = 0

        # 限制最大校正角度
        max_angle = self.config["max_skew_angle"]
        skew_angle = np.clip(skew_angle, -max_angle, max_angle)

        # 仿射变换旋转
        center = (w / 2, h / 2)
        rotation_matrix = cv2.getRotationMatrix2D(center, skew_angle, 1.0)
        corrected = cv2.warpAffine(plate_image, rotation_matrix, (w, h),
                                   flags=cv2.INTER_CUBIC,
                                   borderMode=cv2.BORDER_REPLICATE)

        return corrected, skew_angle

    @timer
    def correct_by_perspective(self, image, plate_region):
        """
        透视变换法 (当车牌有透视畸变时使用)
        使用车牌的四点坐标进行透视校正

        参数:
            image: 原始图像
            plate_region: 车牌定位信息 (含 box 四点坐标)
        """
        if plate_region is None or "box" not in plate_region:
            return image, 0

        box = plate_region["box"].astype("float32")
        corrected = four_point_transform(image, box)
        return corrected, 0

    def correct(self, plate_image, plate_region=None, method="hough"):
        """
        倾斜校正主函数

        参数:
            plate_image: 车牌区域图像
            plate_region: 车牌定位信息
            method: "hough" | "perspective"
        返回:
            corrected: 校正后的图像
            angle: 校正角度
            timing: 耗时
        """
        self._timings = {}

        if not self.config["enable"]:
            return plate_image, 0, {}

        if method == "perspective" and plate_region:
            corrected, angle = self.correct_by_perspective(
                plate_image, plate_region
            )
        else:
            corrected, angle = self.correct_by_hough(
                plate_image, plate_region
            )

        return corrected, angle, dict(self._timings)
