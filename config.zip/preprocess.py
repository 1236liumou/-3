"""
Stage 1: 图像预处理模块
对输入图像进行灰度化、去噪、增强等预处理操作
为后续车牌定位和字符识别提供高质量输入
"""

import cv2
import numpy as np
from .config import PREPROCESS_CONFIG
from .utils import timer, to_gray


class ImagePreprocessor:
    """图像预处理器"""

    def __init__(self, config=None):
        self.config = config or PREPROCESS_CONFIG
        self._timings = {}

    @timer
    def grayscale(self, image):
        """
        灰度化
        RGB -> Gray: Y = 0.299R + 0.587G + 0.114B
        """
        return to_gray(image)

    @timer
    def gaussian_blur(self, image):
        """
        高斯模糊去噪
        使用高斯核卷积，有效抑制高斯噪声
        核大小越大，平滑效果越强
        """
        kernel = self.config["gaussian_blur_kernel"]
        sigma = self.config["gaussian_sigma"]
        return cv2.GaussianBlur(image, kernel, sigma)

    @timer
    def bilateral_filter(self, image):
        """
        双边滤波 (保边去噪)
        同时考虑空间距离和像素值差异
        能在去噪的同时保留边缘信息，适合车牌处理
        """
        return cv2.bilateralFilter(
            image,
            self.config["bilateral_d"],
            self.config["bilateral_sigma_color"],
            self.config["bilateral_sigma_space"],
        )

    @timer
    def clahe_enhance(self, gray_image):
        """
        CLAHE 对比度受限自适应直方图均衡化
        分块进行直方图均衡化，限制对比度增强幅度
        有效改善低照度、低对比度图像质量
        """
        clahe = cv2.createCLAHE(
            clipLimit=self.config["clahe_clip_limit"],
            tileGridSize=self.config["clahe_grid_size"],
        )
        return clahe.apply(gray_image)

    def process(self, image):
        """
        完整预处理流水线:
        1. 灰度化
        2. 双边滤波 (保边去噪)
        3. CLAHE 对比度增强

        返回:
            dict: {
                "gray": 灰度图,
                "enhanced": 增强后的灰度图,
                "denoised": 滤波后的灰度图,
                "color": 原始彩色图,
                "timing": 各步骤耗时,
            }
        """
        self._timings = {}

        # 保留彩色图用于颜色过滤
        color = image.copy()

        # 1. 灰度化
        gray = self.grayscale(image)

        # 2. 双边滤波去噪 (保留边缘)
        denoised = self.bilateral_filter(gray)

        # 3. CLAHE 对比度增强
        enhanced = self.clahe_enhance(denoised)

        return {
            "gray": gray,
            "enhanced": enhanced,
            "denoised": denoised,
            "color": color,
            "timing": dict(self._timings),
        }
