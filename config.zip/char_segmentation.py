"""
Stage 4: 字符分割模块
将车牌图像分割为单个字符图像

核心方法:
  垂直投影法: 统计每列白像素数 -> 找波谷 -> 分割字符
  连通域法:   二值化 -> 连通域分析 -> 按位置排序 -> 筛选字符

辅助步骤:
  1. 车牌标准化 (统一尺寸)
  2. 去除边框
  3. 二值化 (Otsu)
  4. 去除铆钉/螺丝孔噪声

鲁棒性策略:
  - 先用投影法尝试分割
  - 如果分割数量不等于7，自动用连通域法重试
  - 如果仍然不等于7，用动态阈值再试一次投影法
"""

import cv2
import numpy as np
from .config import CHAR_SEGMENTATION_CONFIG
from .utils import timer, to_gray, to_hsv


class CharSegmenter:
    """字符分割器"""

    def __init__(self, config=None):
        self.config = config or CHAR_SEGMENTATION_CONFIG
        self._timings = {}

    @timer
    def resize_plate(self, plate_image):
        """
        车牌标准化: 统一缩放到固定尺寸
        便于后续处理参数一致
        """
        target_w = self.config["resize_width"]
        target_h = self.config["resize_height"]
        return cv2.resize(plate_image, (target_w, target_h),
                          interpolation=cv2.INTER_CUBIC)

    @timer
    def remove_border(self, plate_image):
        """
        去除车牌边框
        裁剪边缘区域，去除蓝色/黄色边框干扰
        """
        if not self.config["remove_border"]:
            return plate_image

        h, w = plate_image.shape[:2]
        margin = self.config["border_margin_ratio"]
        y1, y2 = int(h * margin), int(h * (1 - margin))
        x1, x2 = int(w * margin * 0.5), int(w * (1 - margin * 0.5))
        return plate_image[y1:y2, x1:x2]

    @timer
    def binarize(self, gray_image, color_image=None):
        """
        二值化 — 提取白色字符

        策略 (按优先级):
        1. 颜色空间法 (如果提供彩色图): HSV 中提取白色像素 (低饱和度+高亮度)
           白色字符: S < 60, V > 150
           蓝/绿背景: S > 80
        2. Otsu (fallback): 全局阈值

        返回: 黑底白字 (字符为白色)
        """
        if color_image is not None:
            hsv = to_hsv(color_image)
            s_chan = hsv[:, :, 1]
            v_chan = hsv[:, :, 2]

            # 白色: 低饱和度 + 高亮度
            white_mask = cv2.bitwise_and(
                cv2.inRange(s_chan, 0, 60),
                cv2.inRange(v_chan, 150, 255)
            )

            # 检查白色像素比例 (字符应占 15%-40%)
            white_ratio = np.sum(white_mask > 0) / white_mask.size
            if 0.05 < white_ratio < 0.50:
                return white_mask

        # Fallback: Otsu
        blurred = cv2.GaussianBlur(gray_image, (3, 3), 0)
        _, binary = cv2.threshold(blurred, 0, 255,
                                  cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        white_ratio = np.sum(binary == 255) / binary.size
        if white_ratio > 0.5:
            binary = cv2.bitwise_not(binary)
        return binary

    @timer
    def remove_noise(self, binary_image):
        """
        去除噪声 (铆钉、螺丝孔等)
        使用形态学开操作去除小连通域
        """
        kernel = cv2.getStructuringElement(
            cv2.MORPH_RECT, self.config["morph_close_kernel"]
        )
        # 形态学闭操作连接字符断裂
        closed = cv2.morphologyEx(binary_image, cv2.MORPH_CLOSE, kernel)

        # 连通域分析去噪
        num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
            closed, connectivity=8
        )

        result = np.zeros_like(binary_image)
        for i in range(1, num_labels):  # 跳过背景 (0)
            area = stats[i, cv2.CC_STAT_AREA]
            if area > 30:  # 去除小噪声
                result[labels == i] = 255

        return result

    @timer
    def segment_by_projection(self, binary_image, threshold_ratio=None):
        """
        垂直投影法字符分割

        原理:
        1. 统计每列的白像素总数 (垂直投影)
        2. 投影值低的列是字符间隙 (波谷)
        3. 投影值高的列是字符 (波峰)
        4. 在波谷处切割

        返回: (字符图像列表, 每个字符的 x 范围)
        """
        h, w = binary_image.shape

        # 垂直投影
        projection = np.sum(binary_image > 0, axis=0).astype(np.float32)

        # 平滑投影曲线 (减少噪声导致的误分割)
        kernel_size = 5
        projection = cv2.GaussianBlur(
            projection.reshape(1, -1), (kernel_size, 1), 0
        ).flatten()

        # 动态阈值
        max_proj = np.max(projection)
        if threshold_ratio is None:
            threshold_ratio = self.config["projection_threshold_ratio"]
        threshold = max_proj * threshold_ratio

        # 寻找字符区域 (投影值 > threshold 的连续区间)
        in_char = False
        char_regions = []
        start = 0

        for x in range(w):
            if projection[x] > threshold:
                if not in_char:
                    in_char = True
                    start = x
            else:
                if in_char:
                    in_char = False
                    end = x
                    width = end - start
                    # 筛选字符宽度
                    if width >= self.config["min_char_width"]:
                        char_regions.append((start, end))

        # 处理最后一个字符
        if in_char:
            width = w - start
            if width >= self.config["min_char_width"]:
                char_regions.append((start, w))

        # 分割字符图像
        char_images = []
        char_boxes = []
        max_w = self.config["max_char_width"]
        for start, end in char_regions:
            char_img = binary_image[:, start:end]
            width = end - start
            # 过滤过宽的区域 (可能是两个字符粘连)
            if width > max_w:
                # 尝试从中间分割
                mid = width // 2
                left = char_img[:, :mid]
                right = char_img[:, mid:]
                if left.shape[1] >= self.config["min_char_width"]:
                    char_images.append(left)
                    char_boxes.append((start, 0, mid, h))
                if right.shape[1] >= self.config["min_char_width"]:
                    char_images.append(right)
                    char_boxes.append((start + mid, 0, width - mid, h))
            else:
                char_images.append(char_img)
                char_boxes.append((start, 0, width, h))

        return char_images, char_boxes

    @timer
    def segment_by_connected_components(self, binary_image):
        """
        连通域法字符分割 (备选方案)

        原理:
        1. 连通域分析找到所有连通区域
        2. 按面积和宽高比筛选字符
        3. 按 x 坐标排序

        优势: 对粘连字符更鲁棒
        劣势: 需要更精细的参数调优
        """
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
            binary_image, connectivity=8
        )

        char_info = []
        for i in range(1, num_labels):
            x = stats[i, cv2.CC_STAT_LEFT]
            y = stats[i, cv2.CC_STAT_TOP]
            w = stats[i, cv2.CC_STAT_WIDTH]
            h = stats[i, cv2.CC_STAT_HEIGHT]
            area = stats[i, cv2.CC_STAT_AREA]

            # 筛选条件
            if w < self.config["min_char_width"]:
                continue
            if w > self.config["max_char_width"]:
                continue
            if h < self.config["min_char_height"]:
                continue

            char_info.append({
                "x": x, "y": y, "w": w, "h": h,
                "area": area, "centroid": centroids[i],
            })

        # 按 x 坐标排序
        char_info.sort(key=lambda c: c["x"])

        # 提取字符图像
        char_images = []
        char_boxes = []
        for info in char_info:
            char_img = binary_image[info["y"]:info["y"] + info["h"],
                                   info["x"]:info["x"] + info["w"]]
            char_images.append(char_img)
            char_boxes.append((info["x"], info["y"], info["w"], info["h"]))

        return char_images, char_boxes

    @timer
    def standardize_char(self, char_image):
        """
        字符标准化: 统一缩放到固定大小
        保持宽高比，用黑色填充
        """
        target_w, target_h = self.config["char_resize"]
        h, w = char_image.shape[:2]

        # 计算缩放比例
        scale = min(target_w / w, target_h / h)
        new_w = int(w * scale)
        new_h = int(h * scale)

        resized = cv2.resize(char_image, (new_w, new_h),
                             interpolation=cv2.INTER_CUBIC)

        # 居中放置到目标尺寸
        canvas = np.zeros((target_h, target_w), dtype=np.uint8)
        x_offset = (target_w - new_w) // 2
        y_offset = (target_h - new_h) // 2
        canvas[y_offset:y_offset + new_h, x_offset:x_offset + new_w] = resized

        return canvas

    def _do_segment(self, cleaned, method):
        """执行单次分割"""
        if method == "connected":
            return self.segment_by_connected_components(cleaned)
        else:
            return self.segment_by_projection(cleaned)

    def segment(self, plate_image, method="projection"):
        """
        字符分割主函数 (带 fallback 机制)

        策略:
        1. 用指定方法尝试分割
        2. 如果分割数 != 7，用另一种方法重试
        3. 如果仍 != 7，用更低阈值的投影法再试一次
        4. 取最接近7的结果

        参数:
            plate_image: 车牌区域图像 (彩色或灰度)
            method: "projection" | "connected"
        返回:
            dict: {
                "chars": 标准化字符图像列表,
                "char_boxes": 字符位置列表,
                "binary": 二值化结果,
                "standardized_plate": 标准化车牌,
                "num_chars": 字符数量,
                "timing": 耗时,
                "method_used": 实际使用的方法,
            }
        """
        self._timings = {}

        # 1. 车牌标准化
        standardized = self.resize_plate(plate_image)

        # 2. 去除边框
        no_border = self.remove_border(standardized)

        # 3. 灰度化
        gray = to_gray(no_border)

        # 4. 二值化 (使用颜色信息提取白色字符)
        binary = self.binarize(gray, color_image=no_border)

        # 5. 去噪
        cleaned = self.remove_noise(binary)

        # 6. 字符分割 (带 fallback)
        target_chars = 7
        best_result = None
        best_method_used = method
        best_diff = 999

        # 尝试列表: (method, threshold_ratio)
        attempts = [
            (method, None),                          # 原始方法 + 默认阈值
            ("connected" if method == "projection" else "projection", None),  # 备选方法
            ("projection", 0.08),                    # 低阈值投影法
            ("projection", 0.05),                    # 更低阈值
            ("connected", None),                     # 再试连通域
        ]

        for try_method, try_threshold in attempts:
            if try_method == "projection" and try_threshold is not None:
                char_images, char_boxes = self.segment_by_projection(
                    cleaned, threshold_ratio=try_threshold
                )
            else:
                char_images, char_boxes = self._do_segment(cleaned, try_method)

            num = len(char_images)
            diff = abs(num - target_chars)

            if diff < best_diff:
                best_diff = diff
                best_result = (char_images, char_boxes)
                best_method_used = f"{try_method}" + (
                    f"(threshold={try_threshold})" if try_threshold else ""
                )

            # 如果恰好7个，直接采用
            if num == target_chars:
                break

        char_images, char_boxes = best_result

        # 7. 字符标准化
        standardized_chars = []
        for char_img in char_images:
            std_char = self.standardize_char(char_img)
            standardized_chars.append(std_char)

        return {
            "chars": standardized_chars,
            "raw_chars": char_images,
            "char_boxes": char_boxes,
            "binary": binary,
            "cleaned": cleaned,
            "standardized_plate": standardized,
            "num_chars": len(standardized_chars),
            "method_used": best_method_used,
            "timing": dict(self._timings),
        }
